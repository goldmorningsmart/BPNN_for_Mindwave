#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/10/518:04
# @Author  : DaiPuWei
# E-Mail   : 771830171@qq.com
# @Site    : 
# @File    : __init__.py.py
# @Software: PyCharm

def run_main():
    """
       这是主函数
    """


if __name__ == '__main__':
    run_main()